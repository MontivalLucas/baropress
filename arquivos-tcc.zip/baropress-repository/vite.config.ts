import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "node:path";

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  clearScreen: false,
  server: { port: 1420, strictPort: true },
  build: { rollupOptions: { output: { manualChunks: { "vendor-ui": ["react", "react-dom", "zustand", "lucide-react"], "pdf": ["jspdf"] } } } },
  test: { include: ["src/**/*.test.ts"] },
});
