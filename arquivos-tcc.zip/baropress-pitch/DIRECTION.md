# Direção da apresentação — base escolhida pelo usuário

## Autoridade visual atual
Em 05/11/2026, o usuário substituiu a primeira proposta pela base `C:/Users/Montival Nunes/Desktop/teste arduino/NOVO PROGRAMA/baropress-pitch-src`, considerada mais bonita. A implementação atual preserva sua composição 1920×1080, os 11 quadros, a forma orgânica SVG persistente, a matriz animada e a transformação em relatório. Os apontamentos abaixo documentam a intenção inicial; a base escolhida prevalece em conflitos. A origem permanece intacta. O preço-alvo foi alinhado ao prompt: R$ 3.990.
Tipo: produto tecnológico. Experiência de apresentação, com objetivo comercial.

O usuário fixou a direção: keynote branca e azul, dez cenas, fontes Inter/Geist, elementos persistentes e rigor técnico. Confirmou execução direta em código. Esse briefing prevalece sobre os sorteios de composição para sites convencionais. Seed consultado: seed:67f8066006ce37c9. As alternativas de revista fluorescente, colagem tropical e tecido jacquard não substituem a direção explicitamente solicitada.

## Primeiro viewport
Marca em escala editorial, mensagem humana e forma azul composta dos mesmos 225 elementos que se reorganizam na matriz. Espaço branco, sem painéis de métricas fictícios. A forma muda com a narrativa: percurso, barreira, abertura, matriz e resposta térmica.

## Movimento
Uma instância SVG persistente retargeta posições, formas e cores sem bloquear a navegação. Curva [0.22, 1, 0.36, 1], duração base 950 ms, stagger limitado a aproximadamente 220 ms. Interface se expande por recorte; troca para relatório altera composição. Prefers-reduced-motion e controle de movimento resultam em duração zero. Canvas fornece comparação sintética local.

## Invariantes
Cena entre 0 e 9; hash entre #1 e #10. Atalhos não capturam campos e controles. Interrupções retargetam o estado mais recente. Conteúdo e notas separados em scenes.ts. Nenhuma dependência do aplicativo desktop ou hardware. Apenas ativos anonimizados em public/assets. Fontes locais. Dados sintéticos claramente diferenciados das capturas históricas.

## Critério visual
Leitura de títulos em projeção, capturas reais protagonistas, limites técnicos visíveis. Grade 16:9 preservada em telas pequenas; apresentação recomenda orientação paisagem. Os controles externos mantêm tamanho de interação independente do tamanho do slide.
