# Privacy processing is deterministic: opaque pixel replacement, never reversible CSS masking.
# Raw inputs stay in the ignored .private directory and never enter public/ or dist/.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
$projectPath = Split-Path $PSScriptRoot -Parent
$outputPath = Join-Path $projectPath 'public/assets'
New-Item -ItemType Directory -Force -Path $outputPath | Out-Null
function Export-SafeScreen($sourceIndex, $targetIndex, $regions) {
  $sourcePath = Join-Path $projectPath ".private/screen$sourceIndex.png"
  $original = [System.Drawing.Image]::FromFile($sourcePath)
  $bitmap = New-Object System.Drawing.Bitmap($original.Width, $original.Height)
  $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
  $graphics.DrawImageUnscaled($original, 0, 0)
  $font = New-Object System.Drawing.Font('Segoe UI', 10)
  foreach ($region in $regions) {
    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.ColorTranslator]::FromHtml($region[4]))
    $graphics.FillRectangle($brush, [int]$region[0], [int]$region[1], [int]$region[2], [int]$region[3])
    if ($region.Count -gt 5) { $graphics.DrawString($region[5], $font, [System.Drawing.Brushes]::Gray, [float]($region[0]+8), [float]($region[1]+8)) }
    $brush.Dispose()
  }
  $bitmap.Save((Join-Path $outputPath "software-$targetIndex.png"), [System.Drawing.Imaging.ImageFormat]::Png)
  $graphics.Dispose(); $bitmap.Dispose(); $original.Dispose(); $font.Dispose()
}
Export-SafeScreen 14 0 (, @(0,660,240,61,'#121921','Identificação removida'))
Export-SafeScreen 2 1 @(@(0,660,240,61,'#121921','Identificação removida'),@(280,238,365,386,'#121921','Datas e identificadores removidos'))
Export-SafeScreen 6 2 @(@(0,660,240,61,'#121921','Identificação removida'),@(275,48,230,52,'#121921'),@(545,48,230,52,'#121921'),@(815,48,230,52,'#121921'),@(1085,48,235,52,'#121921'))
Export-SafeScreen 10 3 @(@(0,660,240,61,'#121921','Identificação removida'),@(300,55,350,22,'#121921'),@(930,155,240,26,'#ffffff'),@(428,313,736,82,'#f7f9fc','Dados pessoais e antropométricos removidos'))

Export-SafeScreen 8 4 @(@(0,660,240,61,'#121921','Identificação removida'),@(300,76,265,45,'#121921'))
# A report detail makes the actual document readable without inventing missing pages.
$reportSource = [System.Drawing.Bitmap]::FromFile((Join-Path $outputPath 'software-3.png'))
$reportDetail = $reportSource.Clone([System.Drawing.Rectangle]::new(386,94,820,620), $reportSource.PixelFormat)
$reportDetail.Save((Join-Path $outputPath 'report-detail.png'), [System.Drawing.Imaging.ImageFormat]::Png)
$reportDetail.Dispose()
$reportSource.Dispose()

