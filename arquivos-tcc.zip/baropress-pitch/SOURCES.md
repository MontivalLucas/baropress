# Fontes e rastreabilidade

Consulta em 05/11/2026.

## Base visual
Escolhida expressamente pelo usuário: `C:/Users/Montival Nunes/Desktop/teste arduino/NOVO PROGRAMA/baropress-pitch-src`. A apresentação inclui uma cena de relatório adicional ao storyboard inicial, totalizando 11 cenas. Preservadas forma, narrativa e composições dessa base.

## Projeto técnico
- https://github.com/MontivalLucas/baropress — repositório privado consultado pela conexão autorizada.
- `README.md`: aquisição, análise, registros, histórico, comparação e PDF.
- `docs/MAPEAMENTO_COMPLETO_PROJETO.md`: matriz, firmware, software e arquitetura; levantamento de 26/10/2026.
- `docs/validacao/ENSAIOS.md`: ensaios históricos não equivalem a validação clínica.
- `docs/validacao/LIMITACOES.md`: ADC relativo, resolução, ruído, deriva, orientação e temporização.
- Contexto mestre do backup: https://drive.google.com/file/d/1TeJb6axdKYvKNKI2wcgVTrsW5svSEvgb/view — snapshot de 28/10/2026, commit informado 8580cc2ff254f939f9dbcbafedf0ae4244df1feb. Não se presume igualdade entre capturas históricas e código atual.

## Capturas oficiais
Origem: https://drive.google.com/drive/folders/10PRA-m5a-bNTni47p1LfdRaesSOk_WSk

| Arquivo público | Conteúdo | ID no Drive |
|---|---|---|
| software-0.png | Mapa de calor | 1E5yLHSc31mzlhpem-rOQKOwJCtJD1Vhw |
| software-1.png | Histórico | 1m2HCTBtbeIyYEpEoGj0ZKxu4UBx46oDf |
| software-2.png | Comparação | 1aQ2R8YSkwmYO3jT9fSCgur82MfVqeXKW |
| software-3.png | Relatório | 12bfQA-u7Zrd_MDs2TDHRdaQCanTRsp3P |
| software-4.png | Indicadores | 19yKi8rai2jN3S-0HUgM2nq3ArDICnyav |

Nomes, contatos, CPF, datas identificadoras e antropometria visível foram removidos dos arquivos públicos. Os originais ficam em `.private`, fora do build e da distribuição. As imagens são evidência da interface, não demonstração sintética nem evidência de eficácia clínica. A demonstração animada usa valores sintéticos independentes.

## Hipóteses comerciais
R$ 500 de materiais e R$ 3.990 como preço-alvo vêm do prompt do usuário. A base visual possuía R$ 4.990, corrigido para obedecer ao briefing. A referência de R$ 24–25 mil para BAROSCAN também foi informada pelo usuário; nenhuma cotação verificável foi apresentada. Valores não demonstram equivalência de equipamentos ou viabilidade econômica.

## Lacunas
Vídeo de referência não anexado. Fotografias do hardware final não localizadas nos materiais consultados. A representação é explicitamente conceitual. Custos industriais, logística, manutenção, portabilidade, segurança e requisitos regulatórios dependem de validação.
