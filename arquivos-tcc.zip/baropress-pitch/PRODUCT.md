# BAROPRESS Pitch
<!-- impeccable:product-schema 1 -->
## Platform
web
## Stack
React, TypeScript, Vite, Tailwind CSS e Motion, conforme pedido. Construção direta em código confirmada pelo usuário.
## Users
Apresentadores do TCC, pequenas clínicas, fisioterapeutas autônomos e parceiros de desenvolvimento.
## Product Purpose
Apresentação comercial interativa de dez cenas, orientada à projeção 16:9 e disponível offline após build.
## Capabilities and Constraints
Protótipo experimental 15×15, 225 posições, ESP32 e ADC relativo. Software desktop documentado com mapas, exames, histórico, comparações e relatórios. Sem alegações de validação clínica, certificação, portabilidade ou viabilidade comercial comprovadas. Materiais R$ 500 e preço-alvo R$ 3.990 são hipóteses preliminares. Faixa BAROSCAN R$ 24–25 mil informada pelo usuário, ainda sem cotação verificável.
## Brand Commitments
BAROPRESS. Branco, azul elétrico, tipografia contemporânea; narrativa e dez cenas do prompt. Movimento contínuo do sensor ao software e ao relatório.
## Evidence on Hand
README, mapa do projeto e documentos de validação do GitHub; contexto mestre e capturas do Drive. Não foi fornecido vídeo. Pasta inicial vazia; usuário autorizou seguir o prompt nesta pasta.
## Accessibility & Inclusion
Teclado, redução de movimento, foco visível, controles acessíveis e ajuste para projetores.
