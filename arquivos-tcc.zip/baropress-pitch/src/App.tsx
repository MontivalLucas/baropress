import {useEffect,useState,useContext,createContext,type ReactNode} from 'react'
import {motion,AnimatePresence,useReducedMotion} from 'motion/react'
import {S,SHOTS} from './content'
import {ArrowLeft,ArrowRight,Maximize,Minimize,Presentation,X,Pause,Play,RotateCcw} from 'lucide-react'
import '@fontsource-variable/inter'
const AssetContext=createContext<Record<string,string>>(SHOTS)
let SP=1;const EZ=[.65,0,.25,1] as const
const J=(a:number[])=>a
const JA=J([40,0,0,-60,0,50,-40,0,0,0,60,0,0,-50,0,40]),JB=J([-50,0,0,50,0,-40,50,0,0,0,-50,0,0,40,0,-50]),J0=Array(16).fill(0)
const P=(cx:number,cy:number,rx:number,ry:number,a=.5523,j:number[]=J0)=>`M${cx},${cy-ry} C${cx+a*rx+j[0]},${cy-ry+j[1]} ${cx+rx+j[2]},${cy-a*ry+j[3]} ${cx+rx},${cy} C${cx+rx+j[4]},${cy+a*ry+j[5]} ${cx+a*rx+j[6]},${cy+ry+j[7]} ${cx},${cy+ry} C${cx-a*rx+j[8]},${cy+ry+j[9]} ${cx-rx+j[10]},${cy+a*ry+j[11]} ${cx-rx},${cy} C${cx-rx+j[12]},${cy-a*ry+j[13]} ${cx-a*rx+j[14]},${cy-ry+j[15]} ${cx},${cy-ry}Z`
const BL='#2463EB',ICE='#E4ECFF'
type G={x:number;y:number;s:number;m:'off'|'flat'|'heat'|'logo'}
type H={d:string;f:string;st:string;a:G;b?:G}
const off=(x=960,y=330):G=>({x,y,s:.6,m:'off'})
const HERO=(i:number,ph:number):H=>{
 if(i==0&&!ph)return{d:P(960,330,40,40),f:BL,st:BL,a:off(836,206)}
 const logo:H={d:P(960,330,190,190,.93),f:BL,st:BL,a:{x:836,y:206,s:.6,m:'logo'}}
 return([logo,
 {d:P(1480,540,330,330,.5523,JA),f:BL,st:BL,a:off()},
 {d:P(1600,540,120,380,.9),f:BL,st:BL,a:off()},
 {d:P(1450,540,340,340,.5523,JB),f:BL,st:BL,a:off()},
 {d:P(1400,540,290,290,.93),f:ICE,st:'#CFDCF8',a:{x:1193,y:333,s:1,m:'flat'}},
 {d:P(400,540,290,290,.93),f:ICE,st:'#CFDCF8',a:{x:173,y:313,s:1.1,m:'heat'}},
 {d:P(960,550,840,390,.97),f:'#F3F7FF',st:'#CFDCF8',a:{x:190,y:330,s:.95,m:'heat'}},
 {d:P(960,550,840,390,.97),f:'#F3F7FF',st:'#CFDCF8',a:{x:230,y:340,s:.9,m:'heat'},b:{x:1100,y:340,s:.9,m:'heat'}},
 {d:P(1330,540,370,440,.97),f:'#fff',st:'#CFDCF8',a:{x:1010,y:150,s:.45,m:'heat'}},
 {d:P(1760,960,60,60),f:BL,st:BL,a:off()},
 logo] as H[])[i]}
const hv=(r:number,c:number,alt:boolean)=>{const f=(cx:number,cy:number,sx:number,sy:number)=>Math.exp(-(((c-cx)/sx)**2+((r-cy)/sy)**2))
 const L=.55*f(4,3.2,1.8,1.7)+.95*f(4,11.2,1.6,2),R=.55*f(10,3.2,1.8,1.7)+.95*f(10,11.2,1.6,2),n=((r*7+c*13)%5)/60
 return Math.min(1,(alt?.7:.9)*L+(alt?.95:.7)*R+n)}
const col=(h:number)=>h>.8?'#ed355e':h>.62?'#ff9d35':h>.43?'#dce454':h>.24?'#38D8DC':`rgb(${Math.round(227-191*h)},${Math.round(236-137*h)},${Math.round(253-18*h)})`
function Grid({g,alt=false,ph}:{g:G;alt?:boolean;ph:number}){
 return <motion.div className="absolute z-[2] grid" style={{width:414,height:414,gridTemplateColumns:'repeat(15,22px)',gap:6,transformOrigin:'0 0'}}
  animate={{x:g.x,y:g.y,scale:g.m=='off'?.5:g.s}} transition={{duration:1.3*SP,ease:EZ}}>
  {Array.from({length:225},(_,k)=>{const r=Math.floor(k/15),c=k%15,d=Math.hypot(r-7,c-7)
   const bg=g.m=='heat'?col(hv(r,c,alt)):g.m=='logo'?`rgba(255,255,255,${.3+hv(r,c,false)*.7})`:'#C9D9F8'
   const delay=(g.m=='heat'?(r+c)*.03:g.m=='logo'?.5+d*.02:d*.018)*SP
   return <motion.div data-sensor="" key={k} style={{width:22,height:22,borderRadius:6}} animate={{scale:g.m=='off'?0:1,backgroundColor:bg}} transition={{scale:SP===0?{duration:0}:{type:'spring',stiffness:260,damping:18,delay},backgroundColor:{duration:.9*SP,delay}}}/>})}
 </motion.div>}
const Rv=({children,d=0,cls=''}:{children:ReactNode;d?:number;cls?:string})=><motion.div className={cls}
 initial={SP===0?false:{clipPath:'inset(0 100% 0 0)',filter:'blur(8px)',letterSpacing:'.02em'}} animate={{clipPath:'inset(0 0% 0 0)',filter:'blur(0px)',letterSpacing:'0em'}} transition={{duration:.9*SP,delay:(.25+d)*SP,ease:EZ}}>{children}</motion.div>
function Shot({k,h,pos="left-[170px] top-[270px] w-[1580px]"}:{k:string;h:number;pos?:string}){const assets=useContext(AssetContext);const[ok,set]=useState(true);useEffect(()=>set(true),[k])
 return <motion.div id="official-software" role="tabpanel" key={k} className={"official-shot absolute "+pos+" rounded-3xl overflow-hidden bg-[#0B1017]"} style={{height:h}} initial={SP===0?false:{clipPath:'inset(0 0 0 100%)'}} animate={{clipPath:'inset(0 0 0 0%)'}} transition={{duration:.8*SP,ease:EZ}}>
  {ok&&<img src={assets[k]} alt={`Interface oficial anonimizada: ${k}`} className="w-full h-full object-contain" onError={()=>set(false)}/>}
  {!ok&&<div className="w-full h-full grid place-items-center text-center text-[26px] text-slate-500 p-10">Captura “{k}” indisponível.<br/>Recarregue a apresentação.</div>}</motion.div>}
const Scene=({i,tab,setTab,team}:{i:number;tab:string;setTab:(t:string)=>void;team:string})=>{const c=S[i]
 const L='absolute left-[120px] w-[860px]'
 const T=(top:number,sz=84,w=860)=><div className="absolute left-[120px]" style={{top,width:w}}><Rv cls="font-bold leading-[1.05] tracking-tight" ><span style={{fontSize:sz}}>{c.t}</span></Rv>{c.s&&<Rv d={.2} cls="mt-7 text-[34px] leading-snug text-slate-600">{c.s}</Rv>}</div>
 if(i==0||i==10)return <div className="absolute inset-x-0 text-center" style={{top:i?520:560}}><Rv cls="font-bold text-[120px] leading-none"><span>{c.t}</span></Rv><Rv d={.3} cls="mt-6 text-[38px] text-slate-600">{c.s}</Rv>{i==10&&<Rv d={.6} cls="mt-8 text-[34px] font-semibold text-[#2463EB]">Vamos levar essa solução para mais profissionais?</Rv>}{i==10&&<Rv d={.8} cls="mt-10 text-[24px] text-slate-500">{team} · TCC de Engenharia de Computação · protótipo experimental</Rv>}</div>
 if(i==5)return <><div className="absolute left-[120px] top-[110px] text-[70px] font-bold">{c.t}</div><p className="absolute left-[120px] bottom-[120px] text-[25px] text-slate-600 max-w-[1600px]">{c.s}</p><div className="absolute left-[860px] top-[280px] w-[900px]">{['Tapete 15×15 · 225 pontos','ESP32','Transmissão das leituras','Software BAROPRESS','Mapa de calor relativo'].map((x,k)=><motion.div key={x} className="flex items-center gap-6 py-5 text-[38px] font-semibold" initial={{clipPath:'inset(0 100% 0 0)'}} animate={{clipPath:'inset(0 0% 0 0)'}} transition={{duration:.7*SP,delay:(1.2+k*.35)*SP,ease:EZ}}><span className="grid place-items-center w-16 h-16 rounded-full bg-[#2463EB] text-white text-[28px]">{k+1}</span>{x}</motion.div>)}</div></>
 if(i==6)return <><h2 className="absolute left-[170px] top-[90px] text-[56px] font-bold">O software real.</h2><div className="absolute left-[170px] top-[180px] flex gap-3 z-[4]" role="tablist" aria-label="Recursos do software">{Object.keys(SHOTS).map(k=><button role="tab" aria-selected={tab===k} aria-controls="official-software" key={k} onClick={()=>setTab(k)} className={'rounded-full px-6 py-3 text-[24px] font-semibold '+(tab==k?'bg-[#2463EB] text-white':'bg-[#E4ECFF]')}>{k}</button>)}</div><Shot k={tab} h={620}/><p className="absolute left-[170px] bottom-[120px] text-[23px] text-slate-500">Interface oficial · identificadores removidos · capturas históricas, sem validação clínica.</p></>
 if(i==8)return <>{T(300,84,780)}<div className="absolute left-[1000px] top-[400px] w-[600px] space-y-5">{[100,90,95,70,85,60,80].map((w,k)=><motion.div key={k} className="h-5 rounded-full bg-[#CFDCF8] origin-left" initial={{scaleX:0}} animate={{scaleX:w/100}} transition={{duration:.7*SP,delay:(1.4+k*.12)*SP,ease:EZ}}/>)}</div><Shot k="Relatório" h={660} pos="left-[970px] top-[210px] w-[820px]"/></>
 if(i==7)return <>{T(130,52,1650)}<p className="absolute left-[230px] top-[760px] text-[30px] font-semibold">Avaliação A</p><p className="absolute left-[1100px] top-[760px] text-[30px] font-semibold">Avaliação B</p></>
 if(i==9)return <>{T(120,64,1500)}<div className="absolute left-[120px] top-[560px] w-[1500px] space-y-6 text-[28px] font-semibold">{[['Referência informada (BAROSCAN)',25000,'#0B1120','R$ 24–25 mil'],['Preço-alvo hipotético',3990,BL,'R$ 3.990'],['Estimativa de materiais do protótipo',500,'#38D8DC','≈ R$ 500']].map(([l,v,cl,t],k)=><div key={String(l)}>{l}<div className="flex items-center gap-4"><motion.div className="h-10 rounded-xl" style={{background:String(cl),minWidth:10}} initial={{width:0}} animate={{width:Number(v)/25000*900}} transition={{duration:1*SP,delay:(1+k*.3)*SP,ease:EZ}}/><span style={{color:String(cl)=='#38D8DC'?'#0e8d91':String(cl)}}>{t}</span></div></div>)}</div></>
 if(i==4)return <>{T(330,84,860)}<p className="absolute left-[120px] bottom-[160px] text-[26px] text-slate-500">Ilustração conceitual · Velostat, cobre, multiplexadores e ESP32</p></>
 if(i==3)return <>{T(280,76,900)}<div className="absolute left-[120px] top-[700px] flex gap-5">{['Acessibilidade','Mobilidade (a validar)','Acompanhamento'].map((x,k)=><Rv key={x} d={.5+k*.2} cls="rounded-full bg-[#E4ECFF] px-8 py-5 text-[32px] font-semibold">{x}</Rv>)}</div></>
 return T(i==2?250:330,i==2?76:84)}
const readScene=()=>{const n=Number(location.hash.replace(/^#s?/,''));return Number.isInteger(n)&&n>=1&&n<=S.length?n-1:0}
export default function App(){
 const rm=useReducedMotion()
 const[assets,setAssets]=useState<Record<string,string>>(SHOTS),[assetsReady,setAssetsReady]=useState(false)
 const[i,setI]=useState(readScene),[ph,setPh]=useState(0),[tab,setTab]=useState('Mapa'),[pres,setPres]=useState(false),[sp,setSp]=useState(1),[elapsed,setElapsed]=useState(0),[running,setRunning]=useState(true),[sc,setSc]=useState(()=>Math.min(innerWidth/1920,(innerHeight-70)/1080)),[team,setTeam]=useState('Equipe BAROPRESS'),[full,setFull]=useState(false),[error,setError]=useState('')
 SP=rm?0:sp
 const go=(n:number)=>setI(Math.max(0,Math.min(S.length-1,n)))
 const advance=(delta:number)=>setI(v=>Math.max(0,Math.min(S.length-1,v+delta)))
 async function fullscreen(){try{if(document.fullscreenElement)await document.exitFullscreen();else if(document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen();else setError('Use F11 para abrir tela cheia neste navegador.')}catch{setError('Tela cheia indisponível. Use F11 no navegador.')}}
 useEffect(()=>{if(rm){setPh(1);return}const t=setTimeout(()=>setPh(1),500);return()=>clearTimeout(t)},[rm])
 useEffect(()=>{let active=true;const urls:string[]=[];Promise.all(Object.entries(SHOTS).map(async([key,source])=>{const response=await fetch(source);if(!response.ok)throw new Error('Asset unavailable');const url=URL.createObjectURL(await response.blob());urls.push(url);return [key,url]})).then(entries=>{if(active){setAssets(Object.fromEntries(entries));setAssetsReady(true)}else urls.forEach(URL.revokeObjectURL)}).catch(()=>{if(active)setError('Algumas imagens não carregaram. Recarregue antes de desconectar a internet.')});return()=>{active=false;urls.forEach(URL.revokeObjectURL)}},[])
 useEffect(()=>{history.replaceState(null,'','#s'+(i+1))},[i])
 useEffect(()=>{const hash=()=>setI(readScene());addEventListener('hashchange',hash);return()=>removeEventListener('hashchange',hash)},[])
 useEffect(()=>{const k=(e:KeyboardEvent)=>{
  if(e.altKey||e.ctrlKey||e.metaKey)return
  if((e.target as HTMLElement).closest('input,select,textarea,[contenteditable="true"]'))return
  if((e.key===' '||e.key==='Enter')&&(e.target as HTMLElement).closest('button,a'))return
  if(['ArrowRight','ArrowDown','PageDown',' '].includes(e.key)){e.preventDefault();advance(1)}
  else if(['ArrowLeft','ArrowUp','PageUp'].includes(e.key)){e.preventDefault();advance(-1)}
  else if(e.key==='Home'){e.preventDefault();go(0)}else if(e.key==='End'){e.preventDefault();go(S.length-1)}
  else if(e.key.toLowerCase()==='f')void fullscreen()
  else if(e.key.toLowerCase()==='p')setPres(p=>!p)
  else if(e.key==='Escape')setPres(false)
 };addEventListener('keydown',k);return()=>removeEventListener('keydown',k)},[])
 useEffect(()=>{const f=()=>setSc(Math.min(innerWidth/1920,(innerHeight-70)/1080));f();addEventListener('resize',f);return()=>removeEventListener('resize',f)},[])
 useEffect(()=>{const f=()=>setFull(!!document.fullscreenElement);document.addEventListener('fullscreenchange',f);return()=>document.removeEventListener('fullscreenchange',f)},[])
 useEffect(()=>{if(!running)return;const t=setInterval(()=>setElapsed(v=>v+1),1000);return()=>clearInterval(t)},[running])
 const h=HERO(i,ph),tr={duration:1.3*SP,ease:EZ}
 return <AssetContext.Provider value={assets}><div className="pitch-app" data-assets-ready={assetsReady}>
  <main className="stage-wrapper" aria-label="Apresentação BAROPRESS" style={{width:1920*sc,height:1080*sc}}>
   <div className="stage relative overflow-hidden bg-white" data-scene={i+1} style={{width:1920,height:1080,transform:`scale(${sc})`,transformOrigin:'0 0'}}>
    <div className="stage-meta"><span>BAROPRESS</span><span>Protótipo experimental · TCC</span></div>
    <svg className="absolute inset-0 z-[1]" aria-hidden="true" width="1920" height="1080"><defs><linearGradient id="blue-sculpture" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#6390fa"/><stop offset=".48" stopColor="#2463eb"/><stop offset="1" stopColor="#1647c0"/></linearGradient></defs><motion.path initial={false} animate={{d:h.d,fill:h.f===BL?'url(#blue-sculpture)':h.f,stroke:h.st}} transition={tr} strokeWidth={3} style={{filter:'drop-shadow(0 30px 40px rgba(36,99,235,.18))'}}/></svg>
    <Grid g={h.a} ph={ph}/><Grid g={h.b??{...h.a,m:'off'}} alt ph={ph}/>
    <AnimatePresence initial={false}><motion.section key={i} aria-label={S[i].t} className="absolute inset-0 z-[3]" exit={{clipPath:'inset(0 0 0 100%)'}} transition={{duration:.2*SP}}><Scene i={i} tab={tab} setTab={setTab} team={team}/></motion.section></AnimatePresence>
    <div className="stage-footer"><span>{String(i+1).padStart(2,'0')} / {S.length}</span><span>{i===4?'Hardware conceitual':i===5||i===7?'Demonstração sintética':'A tecnologia deve acompanhar o profissional.'}</span></div>
   </div>
  </main>
  <nav className="presentation-controls" aria-label="Controles da apresentação">
   <button aria-label="Cena anterior" disabled={i===0} onClick={()=>advance(-1)}><ArrowLeft size={18}/></button>
   <div className="scene-dots">{S.map((s,k)=><button key={k} title={s.t} aria-label={'Cena '+(k+1)} aria-current={i===k?'step':undefined} onClick={()=>go(k)}><span/></button>)}</div>
   <button aria-label="Próxima cena" disabled={i===S.length-1} onClick={()=>advance(1)}><ArrowRight size={18}/></button>
   <span className="control-divider"/>
   <button aria-label={full?'Sair da tela cheia':'Tela cheia'} title="Tela cheia (F)" onClick={fullscreen}>{full?<Minimize size={18}/>:<Maximize size={18}/>}</button>
   <button aria-label="Modo apresentador" title="Notas (P)" aria-pressed={pres} onClick={()=>setPres(!pres)}><Presentation size={18}/></button>
   <select aria-label="Duração das animações" value={sp} onChange={e=>setSp(+e.target.value)}><option value={1.6}>Lenta</option><option value={1}>Normal</option><option value={.5}>Rápida</option><option value={0}>Sem movimento</option></select>
  </nav>
  <p className="sr-only" aria-live="polite">Cena {i+1} de {S.length}: {S[i].t}</p>
  {pres&&<aside className="presenter-notes" aria-label="Notas do apresentador"><header><h2>Notas do apresentador</h2><button aria-label="Fechar notas" onClick={()=>setPres(false)}><X size={20}/></button></header><p className="presenter-disclosure">Painel visível nesta tela. Feche antes de projetar.</p><div className="timer"><time>{String(Math.floor(elapsed/60)).padStart(2,'0')}:{String(elapsed%60).padStart(2,'0')}</time><button aria-label={running?'Pausar cronômetro':'Retomar cronômetro'} onClick={()=>setRunning(v=>!v)}>{running?<Pause size={18}/>:<Play size={18}/>}</button><button aria-label="Zerar cronômetro" onClick={()=>setElapsed(0)}><RotateCcw size={18}/></button></div><h3>Cena {i+1} · {S[i].t}</h3><p>{S[i].n}</p><label>Identificação da equipe<input maxLength={65} value={team} onChange={e=>setTeam(e.target.value)}/></label><p className="presenter-disclosure">Setas / espaço: navegar · Home / End: início / fim · F: tela cheia · P: notas.</p></aside>}
  {error&&<div className="error-notice" role="status">{error}<button aria-label="Fechar aviso" onClick={()=>setError('')}><X size={18}/></button></div>}
 </div></AssetContext.Provider>
}


