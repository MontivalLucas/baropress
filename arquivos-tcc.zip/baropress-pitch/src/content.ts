export type Sc={t:string;s?:string;n:string}
export const S:Sc[]=[
{t:'BAROPRESS',s:'A tecnologia deve acompanhar o profissional.',n:'A forma azul cresce, vira a placa e revela os 225 pontos: a marca.'},
{t:'Nem todo profissional atende dentro de uma grande clínica.',n:'Clínica pequena, atendimento autônomo e domiciliar. Sem retratar condições clínicas.'},
{t:'Quando a tecnologia custa caro, o acesso fica limitado.',s:'BAROSCAN: referência de R$ 24–25 mil informada pela equipe. Cotação atual não verificada; sem equivalência técnica presumida.',n:'Valor informado pela equipe; confirmar fonte e data da cotação antes de apresentar.'},
{t:'E se essa tecnologia pudesse chegar a mais profissionais?',n:'Três ideias: acessibilidade, mobilidade (a validar) e acompanhamento.'},
{t:'Conheça o BAROPRESS.',s:'Tapete experimental 15×15 integrado a um software desktop.',n:'Ilustração conceitual até haver fotos reais do hardware.'},
{t:'Como funciona',s:'Dados sintéticos · leituras ADC relativas · sem validação clínica completa de pressão local.',n:'225 pontos → ESP32 → transmissão → software → mapa de calor relativo.'},
{t:'O software real',n:'A placa se expande na interface oficial. Clique nas abas. Capturas históricas anonimizadas; não representam validação clínica.'},
{t:'Não basta observar um resultado. É importante acompanhar a evolução.',s:'Dados sintéticos ilustrativos. Diferenças visuais não comprovam melhora clínica.',n:'O mapa se divide em duas avaliações comparáveis.'},
{t:'Do mapa ao relatório.',s:'Os resultados do exame reorganizados em um documento.',n:'A interface vira a página do relatório.'},
{t:'Um produto de entrada, não uma promessa fechada.',s:'Valores preliminares e hipotéticos. Falta validar fabricação, logística, manutenção, segurança e requisitos regulatórios.',n:'R$ 500 = estimativa de materiais do protótipo; R$ 3.990 = preço-alvo hipotético; R$ 24–25 mil = referência informada.'},
{t:'BAROPRESS',s:'Mais acesso à tecnologia. Mais possibilidades para o cuidado.',n:'CTA: Vamos levar essa solução para mais profissionais? Identificação da equipe editável no modo apresentador.'}]
export const SHOTS:Record<string,string>={'Mapa':'./assets/software-0.png','Indicadores':'./assets/software-4.png','Histórico':'./assets/software-1.png','Comparação':'./assets/software-2.png','Relatório':'./assets/report-detail.png'}
