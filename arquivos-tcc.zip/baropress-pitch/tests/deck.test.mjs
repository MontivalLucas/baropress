import {test} from 'node:test';
import assert from 'node:assert/strict';
import {chromium} from '@playwright/test';
import {mkdir} from 'node:fs/promises';

test('deck: navigation, controls, assets, responsive frames and offline use',async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 try{
 const context=await browser.newContext({viewport:{width:1366,height:768},reducedMotion:'reduce'});
 const page=await context.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:4173');await page.locator('[data-scene="1"]').waitFor();await page.locator('[data-assets-ready="true"]').waitFor();
 const scene=async()=>Number(await page.locator('.stage').getAttribute('data-scene'));
 assert.equal(await page.locator('[data-sensor]').count(),450);
 await page.keyboard.press('ArrowLeft');assert.equal(await scene(),1);
 await page.keyboard.press('Space');assert.equal(await scene(),2);
 await page.keyboard.press('ArrowLeft');assert.equal(await scene(),1);
 await page.keyboard.press('End');assert.equal(await scene(),11);
 await page.keyboard.press('ArrowRight');assert.equal(await scene(),11);
 await page.keyboard.press('Home');assert.equal(await scene(),1);
 for(let i=0;i<10;i++)await page.keyboard.press('ArrowRight');assert.equal(await scene(),11);
 await page.getByLabel('Duração das animações').selectOption('0.5');
 await page.getByRole('button',{name:'Modo apresentador',exact:true}).click();
 await page.getByLabel('Identificação da equipe').fill('Equipe de demonstração');
 await page.getByLabel('Identificação da equipe').press('Space');assert.equal(await scene(),11);
 await page.locator('.presenter-notes').waitFor();await page.getByRole('button',{name:'Pausar cronômetro'}).click();
 await page.getByRole('button',{name:'Zerar cronômetro'}).click();assert.equal(await page.locator('time').textContent(),'00:00');
 await page.getByRole('button',{name:'Fechar notas'}).click();
 await mkdir('.impeccable/review',{recursive:true});
 for(const [width,height] of [[1920,1080],[1366,768],[1280,720],[390,844]]){
 await page.setViewportSize({width,height});
 for(let i=1;i<=11;i++){
 await page.getByRole('button',{name:`Cena ${i}`,exact:true}).click();
 await page.waitForTimeout(150);
 const bounds=await page.locator('.stage').boundingBox();assert.ok(bounds.x>=0&&bounds.y>=0&&bounds.x+bounds.width<=width+1&&bounds.y+bounds.height<=height+1);
 const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert.equal(overflow,false);
 if(width===1366)await page.screenshot({path:`.impeccable/review/scene-${i}.png`});
 }
 if(width===390)await page.screenshot({path:'.impeccable/review/mobile.png'});
 }
 await page.setViewportSize({width:1440,height:900});await page.getByRole('button',{name:'Cena 1',exact:true}).click();await page.screenshot({path:'.impeccable/review/desktop.png'});
 await page.getByRole('button',{name:'Cena 7',exact:true}).click();
 for(const label of ['Mapa','Indicadores','Histórico','Comparação','Relatório']){await page.getByRole('tab',{name:label,exact:true}).click();await page.waitForFunction(()=>{const im=document.querySelector('.official-shot img');return im?.complete&&im.naturalWidth>0});}
 await context.setOffline(true);
 for(const label of ['Mapa','Indicadores','Histórico','Comparação','Relatório']){await page.getByRole('tab',{name:label,exact:true}).click();await page.waitForFunction(()=>{const im=document.querySelector('.official-shot img');return im?.complete&&im.naturalWidth>0});}
 await page.getByRole('button',{name:'Cena 8',exact:true}).click();assert.equal(await scene(),8);await context.setOffline(false);await page.goto('http://127.0.0.1:4173/#s999');assert.equal(await scene(),1);
 assert.deepEqual(errors,[]);
 await context.close();
 }finally{await browser.close()}
});



test('navigation interrupts motion and focused controls keep arrow navigation',async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true});
 try{
 const page=await browser.newPage({viewport:{width:1280,height:720}});
 await page.goto('http://127.0.0.1:4173');
 await page.getByRole('button',{name:'Cena 5',exact:true}).click();
 for(let i=0;i<5;i++)await page.keyboard.press('ArrowRight');
 assert.equal(await page.locator('.stage').getAttribute('data-scene'),'10');
 for(let i=0;i<9;i++)await page.keyboard.press('ArrowLeft');
 assert.equal(await page.locator('.stage').getAttribute('data-scene'),'1');
 await page.waitForTimeout(1800);
 assert.equal(await page.locator('section').count(),1);
 await page.getByLabel('Duração das animações').selectOption('0');
 await page.getByRole('button',{name:'Cena 7',exact:true}).click();
 await page.getByRole('tab',{name:'Relatório',exact:true}).click();
 await page.waitForFunction(()=>{const im=document.querySelector('.official-shot img');return im?.complete&&im.naturalWidth>0});
 assert.equal(await page.locator('.stage').getAttribute('data-scene'),'7');
 }finally{await browser.close()}
});
