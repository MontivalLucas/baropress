# BAROPRESS Pitch

Apresentação web baseada na versão escolhida pelo usuário em `C:/Users/Montival Nunes/Desktop/teste arduino/NOVO PROGRAMA/baropress-pitch-src`. Preserva suas 11 cenas e morph SVG; incorpora cinco capturas oficiais anonimizadas. O aplicativo desktop e a pasta de origem não foram alterados.

## Executar

Node.js 20.19+ ou 22.12+.

```powershell
npm ci
npm run dev -- --host 127.0.0.1 --port 4173
```

Abra http://127.0.0.1:4173. Use setas, espaço, PageUp/PageDown, Home e End. F alterna tela cheia; P abre notas. Os controles inferiores permitem seleção direta de cena e duração da animação. O painel do apresentador inclui cronômetro pausável, reinício e identificação da equipe; ele fica visível na mesma tela, portanto deve ser fechado antes da projeção.

## Build, teste e hospedagem

```powershell
npm run build
npm run preview -- --port 4173
# Em outro terminal, com o preview em execução:
npm test
```

O teste automatizado usa Microsoft Edge instalado, em modo headless. Verifica navegação, limites, campos, notas, cronômetro, imagens, hash inválido, dimensões de projetores e uso offline após carregamento dos ativos. As capturas ficam em `.impeccable/review`.

Cloudflare Pages ou Vercel: diretório raiz `baropress-pitch`, comando `npm run build`, saída `dist`. Não requer servidor de aplicação, banco, Tauri ou dispositivo. Base relativa compatível com subdiretórios. Publique **somente dist/**. Não foi realizado deploy.

Para apresentar sem internet, mantenha `dist` na máquina e execute o preview local antes da apresentação. Fontes e imagens são locais e pré-carregadas. Não é necessário acesso ao Drive ou GitHub. Não há service worker nem promessa de reabertura offline de uma URL hospedada; o servidor local continua necessário. Abrir o HTML por `file://` não é suportado.

## Conteúdo e imagens

- `src/content.ts`: títulos, subtítulos, notas e associação das cinco imagens.
- `src/App.tsx`: forma SVG persistente, matriz, cenas e controles.
- `src/index.css`: sistema visual e acessibilidade dos controles.
- `public/assets/software-*.png`: capturas com anonimização gravada nos pixels.
- `scripts/prepare-assets.ps1`: processamento determinístico; entradas privadas não são distribuídas.
- `SOURCES.md`: proveniência, limites e valores comerciais.

As capturas mantêm interface e medidas históricas após remover identificadores. Os mapas animados são sintéticos. O relatório fornecido é uma captura parcial da interface, não um PDF clínico completo. A proporção 16:9 se mantém em celulares; use paisagem para leitura. O vídeo de referência e fotos finais do hardware não foram fornecidos.

## Limites das afirmações

Protótipo experimental sem validação clínica completa de pressão local. R$ 500 é estimativa inicial de materiais; R$ 3.990 é preço-alvo hipotético. R$ 24–25 mil para BAROSCAN é referência informada pelo usuário, sem cotação atual verificada. Nenhuma equivalência técnica, certificação, ROI, viabilidade ou mobilidade comprovada é afirmada.
