# BAROPRESS — produção de vídeo

Projeto HyperFrames local, independente do pitch interativo. Preparado em 06/11/2026.

## Entregas

- `index.html`: amostra visual de 30 segundos, com abertura, matriz sintética, três capturas reais e encerramento.
- `versions/completo.html`: montagem de 120 segundos com as 12 cenas do pitch atual.
- `compositions/`: cenas editáveis em HTML, com animações GSAP controladas pelo tempo.
- `ROTEIRO.md`: texto sugerido para gravar a locução e tempos de cada bloco.
- `SPEC.md`, `SOURCES.md`, `REVIEW.md`: decisões, origem do material e verificação.

As duas montagens estão sem locução e sem música. A amostra comprova a produção visual; a gravação, escolha de trilha e sincronização final continuam sendo etapas editoriais. Não foi contratado serviço pago nem publicado conteúdo.

## Abrir a prévia e editar

No terminal desta pasta:

```powershell
npm run dev
```

Amostra: http://localhost:3017/#project/baropress-video

O editor permite reproduzir, posicionar o tempo e editar os elementos. Para abrir a versão completa:

```powershell
npm run preview:completo
```

Use a URL impressa pelo comando, na porta 3018. A versão completa já está preparada em `dist/completo`. Prévia, check e render utilizam essa versão sem regenerá-la, preservando alterações feitas no editor. Para atualizar a montagem a partir das fontes em `compositions/` e `versions/completo.html`, execute explicitamente `npm run prepare:completo`. Esse comando sobrescreve a cópia de produção: se editou `dist/completo` no editor, copie suas alterações de volta antes de regenerar.

## Conferir e exportar

```powershell
npm run check
npm run snapshot
npm run render

npm run check:completo
npm run render:completo
```

Amostra: `renders/baropress-amostra-30s.mp4`. Completo: `renders/baropress-pitch-120s.mp4`. Ambos os caminhos são relativos a esta pasta, onde o lançador executa o CLI. A amostra já foi exportada e conferida; a montagem completa está preparada e verificada, ainda sem MP4 final.

Ambos usam 1920×1080, 30 fps, qualidade delivery e um processo de captura por vez. Essa escolha reduz a memória necessária neste computador. O navegador pode atualizar, portanto versões futuras do Chrome podem produzir diferenças mínimas nos pixels.

## Instalação e recuperação

Já preparados: Node.js 24 existente, FFmpeg/FFprobe Essentials 9.0.1 instalado por usuário com WinGet, HyperFrames 0.9.19, GSAP 3.15.0 e Outfit local. Chrome existente atende ao renderizador.

```powershell
npm ci
npm run doctor
```

Para outra máquina Windows, instale também `Gyan.FFmpeg.Essentials` pelo WinGet. O lançador `scripts/hyperframes.mjs` encontra os executáveis mesmo quando o terminal foi aberto antes da instalação. Outros sistemas podem usar FFmpeg/FFprobe no PATH ou as variáveis `HYPERFRAMES_FFMPEG_PATH` e `HYPERFRAMES_FFPROBE_PATH`.

O `package-lock.json` fixa as versões. `undici` está fixado em 7.30.1 por override para corrigir avisos presentes na dependência original do HyperFrames. Não substitua isso por `npm audit fix --force`, que sugeria retroceder o framework.

As quatro skills oficiais foram instaladas em `~/.agents/skills`: `hyperframes`, `hyperframes-cli`, `hyperframes-registry` e `media-use`; disponíveis ao Codex nos próximos turnos.

## Atualizar imagens e conteúdo do pitch

```powershell
npm run assets
```

Esse comando copia apenas as 11 imagens públicas referenciadas pela versão atual de `../baropress-repository/baropress-pitch`, além da fonte e do GSAP instalados. Salva textos, referências e hashes em `assets/source-content.json`. Não copia materiais privados. A sincronização de texto para a versão de vídeo é editorial: atualizar esse snapshot não reescreve as frases condensadas das cenas.

## Inserir áudio

Grave a locução de `ROTEIRO.md`, salve em `assets/audio/` e ajuste os tempos para a fala real. Na raiz da composição, uma faixa segue este contrato:

```html
<audio id="locucao" class="clip" src="assets/audio/locucao.wav"
  data-start="0" data-duration="120" data-track-index="2" data-volume="1"></audio>
```

Só adicione o elemento quando o arquivo existir. Para música, use uma faixa autorizada separada com volume menor e fade de saída. Não use músicas sem licença. Após qualquer alteração, execute o check e revise a prévia antes de exportar.

## Limites

A matriz animada é sintética e representa cruzamentos de leitura, não sensores independentes nem pressão física calibrada. Capturas provam a interface, não eficácia clínica. Fotografias mostram a bancada; `tapete-prototipo.jpg`, copiado por proveniência, é um conceito de acabamento e não está nas cenas da amostra. Preço-alvo atual: R$ 2.990, hipotético; materiais estimados: R$ 500, sem custo industrial completo.

HyperFrames: Apache 2.0. GSAP: licença própria indicada em `assets/vendor/GSAP-README.md`. Outfit: SIL OFL em `assets/fonts/OFL.txt`. Os materiais BAROPRESS mantêm sua autoria original.
