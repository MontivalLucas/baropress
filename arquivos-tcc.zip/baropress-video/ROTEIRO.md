# Locução sugerida — montagem de 120 segundos

Texto editorial de apoio, ainda não gravado. Ajuste os cortes à duração real da voz. Não acelere a fala para compensar texto longo. A versão de 30 segundos é uma amostra visual, não um resumo narrado deste roteiro.

| Tempo | Cena | Locução sugerida |
|---|---|---|
| 0–6 s | Abertura | BAROPRESS. A tecnologia deve acompanhar o profissional. |
| 6–16 s | Contexto | Para quem sente dor ao caminhar, cada passo importa. A avaliação do apoio plantar pode acrescentar informação ao raciocínio do profissional. |
| 16–24 s | Acesso | Equipamentos especializados já existem. Mas o investimento pode ser uma barreira para operações menores. |
| 24–32 s | Proposta | O BAROPRESS investiga uma alternativa de entrada mais acessível, integrando um tapete experimental e um software próprio. |
| 32–42 s | Hardware | Da malha de cobre ao circuito de aquisição, estas fotografias mostram etapas reais da construção e integração em bancada. |
| 42–56 s | Matriz | A matriz reúne quinze linhas e quinze colunas: duzentos e vinte e cinco cruzamentos de leitura. O ESP32 transmite sinais digitais, apresentados como intensidades relativas em ADC. |
| 56–74 s | Software | No software, os registros ganham mapas, controles de visualização e histórico. Estas capturas mostram a interface real. Ajustar a aparência do mapa não equivale a calibrar pressão física. |
| 74–84 s | Comparação | É possível consultar e comparar registros de momentos diferentes. As diferenças não comprovam melhora clínica ou eficácia de tratamento. |
| 84–93 s | Relatório | Os sinais e indicadores podem ser organizados em relatórios exportáveis. São registros do protótipo, não laudos diagnósticos. |
| 93–101 s | Investimento | O preço-alvo hipotético é de dois mil novecentos e noventa reais. O custo completo e a viabilidade ainda precisam ser validados. |
| 101–109 s | Convite | Buscamos parceiros de ensino e pesquisa para ampliar os testes e planejar as próximas etapas de validação. |
| 109–120 s | Artigo | O desenvolvimento e os ensaios preliminares estão documentados em artigo. O aceite editorial informado pela equipe é um marco acadêmico, não validação clínica. |

## Direção

Português brasileiro, ritmo de apresentação acadêmica, aproximadamente 130–150 palavras por minuto, sem entonação de anúncio de tratamento. Os tempos são reservas editoriais e precisam ser medidos após a gravação.

Na cena comercial, os valores completos e a data da referência ficam na imagem. A comparação é apenas financeira: não apresentar equivalência de desempenho. O artigo mantém DOI pendente, sem inventar referência de publicação definitiva.
