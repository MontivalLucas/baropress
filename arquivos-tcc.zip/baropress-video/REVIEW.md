# Revisão de produção — 06/11/2026

## Entrega e decisões

A proposta aceita foi executada como amostra visual de 30 segundos: abertura do pitch, matriz, capturas reais do software e encerramento. Também foi preparada uma montagem completa editável de 120 segundos em 12 cenas, sem alterar a apresentação original. Não foram exploradas narrativas alternativas porque o usuário aprovou a proposta anterior e pediu sua execução.

Amostra em `renders/baropress-amostra-30s.mp4`: MP4 H.264, 1920×1080, 30 fps, 900 quadros, duração medida de 30,000 segundos e 3.762.265 bytes. Render real concluído com um processo, Chrome em cache e captura por screenshot com GPU de hardware; captura levou aproximadamente 90 segundos. Encoding ocorreu junto da captura.

## Provas

- Check oficial da amostra: aprovado, sem erros de lint, execução, layout, motion ou contraste. Único aviso final: `film_silent`, esperado nesta etapa.
- Check oficial do completo: aprovado; relatório em `check-completo.json`. Há avisos editoriais de silêncio e de pausas para leitura/locução. Não equivalem a erros de carregamento ou congelamento do renderizador.
- Amostra: folhas de cenas, cortes e formato de celular inspecionadas; a sobreposição inicial de rótulos em Software foi corrigida com `immediateRender:false` no segundo tween do rótulo intermediário. Nova inspeção em 14,3, 16, 20 e 24 segundos confirmou a correção.
- Completo: todas as 12 cenas e as 11 faixas de cortes revisadas nas folhas geradas. Fotografias reais, comparação, relatório e artigo carregaram. Não foi renderizado um MP4 de 120 segundos nesta preparação.
- Arquivo final: ffprobe confirmou duração, codec, dimensões, taxa e número de quadros. Quadros decodificados em 16 e 28 segundos, mais uma folha com seis instantes, conferidos visualmente contra a prévia. Evidências em `review/`.
- Auditoria npm: zero vulnerabilidades após fixar a dependência transitiva undici em 7.30.1. Lockfile preservado.
- Prévia local na porta 3017: resposta HTTP 200 e sessão persistente pronta, com rota de projeto. Solicitada abertura no painel do Codex.
- Diagnóstico: FFmpeg, FFprobe e Chrome encontrados. Ferramentas opcionais de nuvem, transcrição e modelos de voz não foram instaladas porque não participam desta entrega.

## Limites e próxima etapa editorial

Não há locução, trilha ou efeitos sonoros. Portanto não houve avaliação auditiva, medição de mixagem ou sincronização de voz. O roteiro está pronto para gravar e ajustar à fala real; nenhum serviço pago foi usado.

O ponto mais fraco é a leitura de detalhes pequenos das capturas quando exibidas no celular. As telas estabelecem contexto do produto, sem exigir a leitura de cada controle. Para uma versão social, a melhoria indicada é criar recortes específicos do mapa e do histórico, preservando rótulos e valores originais. A página do artigo é mostrada como evidência documental; seu corpo não foi composto para leitura integral no vídeo.

Pausas maiores na versão completa reservam espaço para a futura fala. A duração editorial de 120 segundos ainda deve ser ajustada após a gravação, principalmente nos blocos da matriz e do histórico. As transições são deliberadamente contidas para preservar o visual do pitch.

O computador tem cerca de 8 GB de RAM e o diagnóstico ainda alerta para pouca memória livre. O fluxo local foi comprovado com a amostra; manter um processo de captura e evitar outros trabalhos pesados durante exportações. Não é necessário instalar Docker, modelos grandes de voz ou o aplicativo desktop para continuar.
