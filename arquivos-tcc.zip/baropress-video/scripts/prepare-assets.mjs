import { mkdir, copyFile, writeFile, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const pitch = path.resolve(root, '../baropress-repository/baropress-pitch');
const content = await import(pathToFileURL(path.join(pitch, 'src/content.ts')));
await mkdir(path.join(root, 'assets/shots'), { recursive: true });
await mkdir(path.join(root, 'assets/fonts'), { recursive: true });
await mkdir(path.join(root, 'assets/vendor'), { recursive: true });
const files = [...new Set([
  ...Object.values(content.SHOTS), ...content.HW_PHOTOS.map(item => item.src), content.ARTICLE.image,
])];
const ledger = [];
for (const src of files) {
  const source = path.join(pitch, 'public', src);
  const target = path.join(root, 'assets', src);
  const bytes = await readFile(source);
  await copyFile(source, target);
  ledger.push({ source: path.relative(root, source).replaceAll('\\', '/'), file: `assets/${src}`, sha256: createHash('sha256').update(bytes).digest('hex') });
}
await copyFile(path.join(root, 'node_modules/gsap/dist/gsap.min.js'), path.join(root, 'assets/vendor/gsap.min.js'));
await copyFile(path.join(root, 'node_modules/gsap/README.md'), path.join(root, 'assets/vendor/GSAP-README.md'));
await copyFile(path.join(root, 'node_modules/@fontsource-variable/outfit/files/outfit-latin-wght-normal.woff2'), path.join(root, 'assets/fonts/outfit-latin.woff2'));
await copyFile(path.join(root, 'node_modules/@fontsource-variable/outfit/LICENSE'), path.join(root, 'assets/fonts/OFL.txt'));
await writeFile(path.join(root, 'assets/source-content.json'), JSON.stringify({ scenes: content.S, references: content.REFERENCES, article: content.ARTICLE, ledger }, null, 2) + '\n');
console.log(`${files.length} imagens copiadas do pitch atual; fonte, GSAP e proveniência locais.`);
