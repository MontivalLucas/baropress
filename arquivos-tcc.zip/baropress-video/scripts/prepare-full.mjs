import { mkdir, cp, copyFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const target = path.join(root, 'dist/completo');
await mkdir(target, { recursive: true });
for (const folder of ['assets', 'compositions']) {
  await cp(path.join(root, folder), path.join(target, folder), { recursive: true });
}
await copyFile(path.join(root, 'versions/completo.html'), path.join(target, 'index.html'));
await copyFile(path.join(root, 'hyperframes.json'), path.join(target, 'hyperframes.json'));
await writeFile(path.join(target, 'meta.json'), JSON.stringify({ id: 'baropress-completo', name: 'BAROPRESS — Pitch completo de 120 segundos' }, null, 2));
console.log('Versão completa preparada em dist/completo. Edite compositions/ e versions/completo.html; execute novamente para atualizar.');
