import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const project = fileURLToPath(new URL('../', import.meta.url));
const env = { ...process.env };
// A instalação do WinGet pode ocorrer depois que o Codex abriu seu terminal.
if (process.platform === 'win32') {
  const packages = path.join(env.LOCALAPPDATA, 'Microsoft', 'WinGet', 'Packages');
  const links = path.join(env.LOCALAPPDATA, 'Microsoft', 'WinGet', 'Links');
  const { readdirSync } = await import('node:fs');
  const ffmpegPackage = existsSync(packages) && readdirSync(packages).find(name => name.startsWith('Gyan.FFmpeg.Essentials_'));
  const packageRoot = ffmpegPackage && path.join(packages, ffmpegPackage);
  const build = packageRoot && readdirSync(packageRoot).find(name => name.startsWith('ffmpeg-'));
  const bin = build && path.join(packageRoot, build, 'bin');
  const pathKey = Object.keys(env).find(key => key.toLowerCase() === 'path') || 'PATH';
  env[pathKey] = [bin, links, env[pathKey]].filter(Boolean).join(path.delimiter);
  for (const name of ['ffmpeg', 'ffprobe']) {
    if (bin && existsSync(path.join(bin, `${name}.exe`))) {
      env[`HYPERFRAMES_${name.toUpperCase()}_PATH`] ??= path.join(bin, `${name}.exe`);
    }
  }
}
if (os.totalmem() < 9 * 1024 ** 3) env.PRODUCER_LOW_MEMORY_MODE ??= 'true';
const cli = path.join(project, 'node_modules', 'hyperframes', 'bin', 'hyperframes.mjs');
if (!existsSync(cli)) throw new Error('Dependências ausentes. Execute npm ci na pasta baropress-video.');
const child = spawn(process.execPath, [cli, ...process.argv.slice(2)], {
  cwd: project, env, stdio: 'inherit', windowsHide: true,
});
child.on('error', error => { console.error(error.message); process.exitCode = 1; });
child.on('exit', (code, signal) => { process.exitCode = code ?? (signal ? 1 : 0); });
