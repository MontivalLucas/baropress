# BAROPRESS — especificação de produção

Base: apresentação de 12 cenas em `../baropress-repository/baropress-pitch`. O conteúdo técnico e os valores dessa versão prevalecem sobre o pitch antigo.

Objetivo: mostrar a continuidade entre a matriz experimental, o sinal relativo e sua organização no software real. Público: banca e parceiros de ensino/pesquisa.

- Amostra: 30 s × 30 fps = 900 quadros, 1920 × 1080, MP4 H.264.
- Vídeo completo: montagem editável de 120 s, 3600 quadros, mesma resolução. Ainda não é uma fala gravada nem a versão final de apresentação.
- Fonte: Outfit variável local, títulos 72–120 px / 650–750, apoio 32–40 px, notas 28–30 px.
- Paleta do pitch: azul #2457E7, marinho #0D1830, gelo #F5F8FF, branco #FFFFFF, ciano #38D8DC. Sem novos gradientes, partículas ou efeitos de lente.
- Margem de leitura: 192 px horizontal e 108 px vertical. Interface real pode ocupar mais da largura para estabelecer contexto.
- Movimento: entradas 0,5–0,8 s com power3.out; reorganização 0,9–1,2 s com power3.inOut; stagger da matriz 0,006 s; nenhuma animação infinita, relógio de parede ou aquisição em tempo real.
- Áudio: sem trilha ou locução nesta amostra. Não há música fornecida nem conta HeyGen conectada. A duração está preparada para receber locução; nenhum serviço pago é necessário para renderizar as imagens.

## Amostra, em quadros

| Quadros | Cena | Leitura e movimento |
|---|---|---|
| 0–179 | abertura | Marca e frase do pitch presentes desde o início; matriz da marca se abre em 0,8 s. |
| 180–419 | matriz | 225 cruzamentos; varredura ilustrativa e organização do fluxo de aquisição. Cores identificadas como dados sintéticos. |
| 420–779 | software | Captura real do mapa; depois indicadores e histórico, 4 s por tela. Sem cursor ou interação inventada. |
| 780–899 | encerramento | Marca e convite à pesquisa. Manter estado legível até o último quadro. |

## Proibido

Não transformar ADC em kPa; não apresentar cruzamentos como sensores independentes; não prometer eficácia clínica; não animar valores dentro das capturas; não usar preço antigo de R$ 3.990. Não tratar conceito de acabamento como foto de equipamento final. Não redesenhar dashboard, não colocar títulos sobre a captura escurecida, não usar tela pequena em perspectiva 3D.

## Verificação

Gate oficial `check`; amostras no meio de cada cena e nos cortes; seek em ordem inversa para confirmar determinismo; renderização real da amostra; ffprobe para duração, resolução e fps; quadros decodificados do MP4 para comparar com a prévia. Revisão de áudio não se aplica ao arquivo silencioso.
