# Fontes e proveniência

Preparado em 06/11/2026. Fonte principal: `../baropress-repository/baropress-pitch/src/content.ts` e os arquivos públicos por ele referenciados. O pitch antigo em `../baropress-pitch` não é a referência editorial deste vídeo.

- `assets/source-content.json`: cópia do conteúdo e das referências vigentes no momento da preparação; cada imagem inclui caminho de origem e SHA-256.
- Capturas reais: mapa, indicadores, histórico, comparação e relatório. Identificação ocultada no material público de origem. Não recriamos valores ou controles para sugerir interações.
- Fotografias reais: malha de cobre, Velostat, circuito e tapete montado.
- Conceito de produto: `tapete-prototipo.jpg`, identificado na fonte como conceito; não é foto de produto final.
- Artigo: primeira página fornecida pelo projeto. Aceite na Práxis Teológica informado pela equipe; DOI pendente. A informação não foi revalidada com a revista nesta preparação.
- Marca/matriz: geometria SVG e função sintética adaptadas de `src/App.tsx`, sem apresentar dados sintéticos como medição real.
- Preço-alvo R$ 2.990 e materiais ≈ R$ 500: hipóteses constantes da versão atual. BaroScan R$ 24.961,25: referência do pitch com consulta indicada em 06/11/2026; não houve nova consulta comercial nesta tarefa.

Referências científicas e seus limites permanecem no snapshot. O vídeo condensa a narrativa e não substitui o artigo ou documentação de ensaios.

Ferramentas: https://github.com/heygen-com/hyperframes, versão npm 0.9.19; skills oficiais da tag correspondente. Catálogo consultado para transições e apresentação de produto. Os itens encontrados não substituem a matriz específica do pitch; reutilizamos a geometria do projeto e primitivas GSAP em vez de importar cenas genéricas ou mockups de aplicativo.
